## Natives that use this enum
| Name                        | Hash               |
|-----------------------------|--------------------|
| PED::SET_PED_COMBAT_ABILITY | 0xC7622C0D36B2FDA8 |
## Enum
```cpp
enum CCombatData__Ability
{
	CA_Poor = 0,
	CA_Average = 1,
	CA_Professional = 2,
	CA_NumTypes = 3,
};
```
