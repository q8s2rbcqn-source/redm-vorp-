## Natives that use this enum
| Name                                                  | Hash               |
|-------------------------------------------------------|--------------------|
| UISTICKYFEED::\_UI\_STICKY\_FEED\_IS\_CHANNEL\_ACTIVE | 0xC5C395C60B542A3C |
## Enum
```cpp
enum eUIStickyFeedChannel
{
	kStickyFeedChannel_Invalid = 0,
	kStickyFeedChannel_StatusAlert = 1,
	kStickyFeedChannel_Warning = 2,
	kStickyFeedChannel_WarningSideMenu = 3,
	kStickyFeedChannel_Toast = 4,
	kStickyFeedChannel_0xD6C6B7A5 = 5,
	kStickyFeedChannel_Count = 6,
};
```
