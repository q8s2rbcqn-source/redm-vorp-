## Natives that use this enum
| Name                               | Hash               |
|------------------------------------|--------------------|
| HUD::\_UI\_PROMPT\_SET\_PRIORITY   | 0xCA24F528D0D16289 |
## Enum
```cpp
enum ePromptPriority
{
	PP_Low = 0,
	PP_Normal = 1,
	PP_High = 2,
	PP_MissionCritical = 3,
};
```