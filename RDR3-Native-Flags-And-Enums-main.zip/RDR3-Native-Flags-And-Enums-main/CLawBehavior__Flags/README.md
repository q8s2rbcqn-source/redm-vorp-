## Natives that use this enum
| Name                                  | Hash               |
|---------------------------------------|--------------------|
| LAW::\_SET\_PED\_LAW\_BEHAVIOUR       | 0x819ADD5EF1742F47 |
## Enum
```cpp
enum CLawBehavior__Flags
{
	IsLaw = 0,
	IsCop = 1,
	CanReportSpottedPlayers = 2,
	UseRegularBlips = 3,
	IsGuard = 4,
	IsLawDispatchLeader = 5,
	IsBountyHunter = 6,
	IsSheriff = 7,
	IsPolice = 8,
	DestroyWhenOrderRemoved = 9,
	IsBlackwater = 10,
	IsPinkerton = 11,
	NoticeIgnoresPassivelyWanted = 12,
	IsDeputy = 13,
	_0x727E0188 = 14,
	_0x07088993 = 15,
	IsDeputyResident = 16,
	CanIdentifyDisguisedCriminals = 17,
};
```