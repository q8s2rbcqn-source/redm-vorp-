## Natives that use this enum
| Name                                                           | Hash               |
|----------------------------------------------------------------|--------------------|
| INVENTORY::\_INVENTORY\_GET\_IS\_INVENTORY\_ITEM\_SOUND\_VALID | 0x2BAE4880DCDD560B |
| INVENTORY::\_INVENTORY\_GET\_INVENTORY\_ITEM\_SOUND            | 0x2E1CDC1FF3B8473E |
## Enum
```cpp
enum CItemInfoSoundsInterface__sSoundsInfo__eSoundType
{
	SI_SFX_PURCHASE = 0,
	SI_SFX_SELL = 1,
	SI_SFX_USE = 2,
};
```
