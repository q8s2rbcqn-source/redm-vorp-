## Natives that use this enum
| Name                                    | Hash               |
|-----------------------------------------|--------------------|
| PED::\_PED\_SET\_SIMPLE\_PLAYER\_MEMORY | 0xC494C76A34266E82 |
## Enum
```cpp
enum _0x6ED55512
{
	PutOnDisguise = 0,
	EnteredScenario = 1,
	_0xB8FFD209 = 2,
	KnockedOut = 3,
	_0xF95414AC = 4,
	_0x75E81EB4 = 5,
	_0x61B77DB1 = 6,
	_0x3317A66E = 7,
	_0x7DC01894 = 8,
	_0xE2AAEEED = 9,
	_0x0D565D85 = 10,
	_0x7A5DD4CC = 11,
	_0x15CE18DA = 12,
	TookOffDisguise = 13,
	_0xAECEB3D2 = 14,
	SwappedHat = 15,
	_0x44AAB30E = 16,
	PlayedBumpAnimDialogue = 17,
	LeftCampfireScenario = 18,
	_0x74FA1EF6 = 19,
	PlayerEvasiveAnim = 20,
	_0x412C995B = 21,
	_0x9F49EE67 = 22,
	_0x52C9695B = 23,
	_0x7BFEBAE8 = 24,
	_0xA433BBD5 = 25,
	TriggeredInteractionSpeech = 26,
	_0x4FC392A2 = 27,
	_0x5A2F5822 = 28,
};
```
