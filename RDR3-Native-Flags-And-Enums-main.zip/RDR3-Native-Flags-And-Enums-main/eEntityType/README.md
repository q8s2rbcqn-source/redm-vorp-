## Natives that use this enum
| Name                                            | Hash               |
|-------------------------------------------------|--------------------|
| ENTITY::GET\_ENTITY\_TYPE                       | 0x97F696ACA466B4E0 |
## Enum
```cpp
enum eEntityType
{
	ET_NONE,
	ET_PED,
	ET_VEHICLE,
	ET_OBJECT,
};
```