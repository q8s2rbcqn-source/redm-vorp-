# RDR3 Native Flags And Enums
Feel free to make pull requests, jsut make sure the format is the same
