## Natives that use this enum
| Name                                            | Hash               |
|-------------------------------------------------|--------------------|
| ENTITY::\_SET\_ENTITY\_THREAT\_TIER             | 0x4B436BAC8CBE9B07 |
| ENITTY::\_GET\_ENTITY\_THREAT\_TIER             | 0xE12F56CB25D9CE23 |
## Enum
```cpp
enum eEntityThreatTier
{
	THREAT_NONE = -1,
	THREAT_LOW,
	THREAT_MED,
	THREAT_HIGH
};
```