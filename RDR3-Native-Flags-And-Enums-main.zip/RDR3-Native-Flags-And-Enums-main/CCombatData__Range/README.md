## Natives that use this enum
| Name                      | Hash               |
|---------------------------|--------------------|
| PED::SET_PED_COMBAT_RANGE | 0x3C606747B23E497B |
## Enum
```cpp
enum CCombatData__Range
{
	CR_Invalid = -1,
	CR_Near = 0,
	CR_Medium = 1,
	CR_Far = 2,
	CR_VeryFar = 3,
	CR_NumRanges = 4,
};
```
