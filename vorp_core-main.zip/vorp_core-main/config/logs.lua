Logs = {}

Logs.Whitelist = ""                -- only if you use whitelist in vorp core

Logs.EnableWebhookJoinleave = true -- Enable webhooks for player join and leave?

Logs.JoinWebhookURL = ""           -- only if you use join leave in vorp core

Logs.LeaveWebhookURL = ""          -- only if you use join leave in vorp core

Logs.DeathWebhookURL = ""          -- only if you use death webhook in vorp core