## Audio Flags

## Example

```lua

	Citizen.InvokeNative(0xB9EFD5C25018725A,"OpenWorldMusicDisabled",true)   -- SET_AUDIO_FLAG (disables default ambient music)

```
<br>
<h2>Some known Audio Flags.</h2>

	AllowScriptedSpeechInSlowMo
	AllowScriptStreamVirtualSlotFallback
	DisableAbortConversationForDeathAndInjury
	DisableInhibitIdleMusicInCamp
	DisableSubtitleDistancePriorityFiltering
	EnableBarFightConductor
	EnableCutsceneMusic
	EnableHeadsetBeep
	EnableIdleMusic
	EnableMeleeDynMixScene
	ForceUrgentPlayerHorseSpurs
	MusicIgnoreDeathArrest
	MusicIgnoreScreenFade
	naSETVehExitUseActiveTransportOnly
	OpenWorldMusicDisabled
	OpenWorldMusicOnMission
	SuppressNewAndExistingTrainWhistles
	SuppressNewTrainWhistles



