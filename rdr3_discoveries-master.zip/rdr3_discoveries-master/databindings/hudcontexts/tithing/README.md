## Hash
1670279562

## Tree structure
```bash
└── Tithing : Container
    ├── Supplies : String
    ├── CampFunds : Container
    │   ├── dollars : Int
    │   └── cents : Int
    └── PlayerCash : Container
        ├── dollars : Int
        └── cents : Int
```
