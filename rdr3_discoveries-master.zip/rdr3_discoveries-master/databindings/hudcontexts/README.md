## What is its specificity?
A hudcontext is an interface that can be shown/hide.

| References
| --
DisableHudContext(component --[[ Hash ]])
EnableHudContext(component --[[ Hash ]])
EnableHudContextThisFrame(component --[[ Hash ]])
