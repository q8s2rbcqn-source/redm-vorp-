## What is its specificity?
These are interfaces that activate/deactivate themselves by changing the value of one of their data often called "isVisible".
