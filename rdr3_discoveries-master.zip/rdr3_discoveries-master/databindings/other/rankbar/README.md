## Tree structure
```bash
└── mp_rank_bar : container
    ├── rank_text : string
    ├── rank_header_text : string
    ├── rank_header_text_alpha : int (from 0-255)
    ├── xp_bar_value : int
    ├── xp_bar_minimum : int
    └── xp_bar_maximum : int
```
