## Tree structure
```bash
└── PassiveIcon
    ├── isVisible : bool
    └── setState : int (from 1-3)
```
