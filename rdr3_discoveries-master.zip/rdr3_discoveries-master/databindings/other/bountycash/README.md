## Tree structure
```bash
└── BountyCash
    ├── State : bool
    └── Title : string
```
