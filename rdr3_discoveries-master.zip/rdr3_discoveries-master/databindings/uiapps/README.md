## What is its specificity?
A uiapp is an interface that can be started and stopped.

## Warning
Sometimes uiapps use another thing called Statemachine and Flowblocks, if some apps don't work it's could be because you must use their Statemachine and Flowblock.

| LaunchUiappByHash(hash)
| --
1976336482
joaat("store")
joaat("Collectors")
joaat("Map")
joaat("coupons")
joaat("crafting")
joaat("fast_travel_menu")
joaat("hub")
joaat("opening_credits_sequence")
joaat("trader")
joaat("weapon_locker")

| LaunchUiappWithEntry(string, string)
| --
"player_menu", "mp"
"player_menu", "mp_matchmaking"
"player_menu", "mp_camp_selection"
"player_menu", "mp_moonshine_selection"
"player_menu", "mp_moonshine_property_player_invite"
"player_menu", "mp_invites"
"player_menu", "mp_post_office"
"player_menu", "mp_emote_types"
"player_menu", "mp_minigame"
"player_menu", "mp_minigame_landing"
"player_menu", "mp_minigame_jip_landing"
"player_menu", "mp_minigame_invites"
"player_menu", "mp_minigame_invite_players"
"progress_menu", "progress_mp_moonshine"
"social_club_feed", "launch_to_photos"

| LaunchUiappByHashWithEntry(hash, hash)
| --
joaat("LEADERBOARDS"), joaat("LEADERBOARD")
joaat("LEADERBOARDS"), joaat("post_match")
joaat("social_club_feed"), joaat("launch_to_photos")
joaat("Rewards"), joaat("rewards_vip_info")
joaat("Rewards"), joaat("rewards_vip")
joaat("Abilities"), joaat("FromToast")
-696756762, joaat("mp_mission_info_screen")
joaat("help_menu"), joaat("Poker")
1976336482, 1261159557
joaat("satchel"), joaat("ingame")
joaat("satchel"), joaat("SHOP")
joaat("satchel"), 0
joaat("translation_overlay"), joaat("GENERIC")
joaat("translation_overlay"), joaat("newspaper")
joaat("translation_overlay"), joaat("Minigame")
joaat("translation_overlay"), joaat("journal")
joaat("translation_overlay"), joaat("catalogue")
joaat("shop_browsing"), joaat("horse_stats_info_card")
joaat("shop_browsing"), joaat("catalog_item_inspection")
joaat("shop_browsing"), joaat("info_card_entry_point")
joaat("player_menu"), 104220731
joaat("player_menu"), -464479041
joaat("player_menu"), -822338381
joaat("player_menu"), joaat("mp_legendary_bounty_replay_menu")
joaat("player_menu"), -1499717358
joaat("opening_credits_sequence"), joaat("scene_one")
joaat("opening_credits_sequence"), joaat("scene_two")
joaat("lobbies_menu"), joaat("default_entry")
joaat("character_creator"), joaat("photo_overlay")
joaat("shop_menu"), joaat("generic_shop")
