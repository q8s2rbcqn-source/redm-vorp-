## Hashname
TRANSLATION_OVERLAY

## Entry hashname
CATALOGUE

## Tree structure
```bash
└── Translate : Container
    └── Catalogue : Container
        ├── divider<int> : Container
        │   └── isVisible : Bool
        └── textField<0 or 2> : Container
            ├── text : String
            └── style : Int (from 0 to 3)
```
