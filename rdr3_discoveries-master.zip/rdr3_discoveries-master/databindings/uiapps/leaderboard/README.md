## TODO
The interface is not fully discovered, you have to understand how to edit the scoreboard lines.

## Hashname
LEADERBOARDS

## Entry hashname
LEADERBOARDS

## Tree structure
```bash
└── PostMatchAndLeaderboard : Container
    ├── Title : Container
    │   ├── Heading : String
    │   ├── HeadingColor : Int
    │   ├── Stat<1-3> : String
    │   ├── Stat<1-3>Color : Int
    │   ├── StatRounds : String
    │   └── StatRoundsColor : Int
    └── LeaderboardList : Item List
        └── LeaderboardListItem : Container
```
