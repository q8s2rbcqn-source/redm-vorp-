## Some FLEE ATTRIBUTES Flags

## Example

```lua
	Citizen.InvokeNative(0x70A2D1137C8ED7C9,ped_id,4194304,true)  -- SET_PED_FLEE_ATTRIBUTES ped cant enter vehicles, when flee;
```

<h2>Some known FLEE ATTRIBUTES Flags.</h2>

FlagId | FLEE ATTRIBUTE Action Result
----------- | --------------------------
0 | unknown yet
1 | unknown yet
2 | unknown yet
4 | unknown yet
8 | unknown yet
16 | unknown yet
32 | unknown yet
64 | unknown yet
128 | unknown yet
256 | unknown yet
512 | unknown yet
1024 | unknown yet
2048 | unknown yet
4096 | unknown yet
8192 | unknown yet
16384 | unknown yet
32768 | unknown yet
65536 | FA_FORCE_EXIT_VEHICLE
131072 | unknown yet
262144 | unknown yet
524288 | unknown yet
1048576 | FA_DISABLE_MOUNT_USAGE
2097152 | unknown yet
4194304 | FA_DISABLE_ENTER_VEHICLES