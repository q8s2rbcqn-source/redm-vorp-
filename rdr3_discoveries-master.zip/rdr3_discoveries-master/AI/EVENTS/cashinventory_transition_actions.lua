local cashinventory_transition_actions = {

	"BATCH",                 -- 0x8FB972FA		-- -1883671814
	"BUYAWARD",              -- 0x20493AF8		-- 541670136
	"BUYBUNDLE",             -- 0x7DF45342		-- 2113164098
	"CLAIMAWARD",            -- 0x266F0442		-- 644809794
	"CLAIMLOOT",             -- 0x8C646D2F		-- -1939575505
	"CLAIMSPLITAWARD",       -- 0xD8AD5E2C		-- -659726804
	"MOVEITEMS",             -- 0x459FC6F7		-- 1168099063
	"SELL",                  -- 0xB16AB6C7		-- -1318406457
	"SPEND",                 -- 0xAC23E126		-- -1406934746
	"UPDATE",                -- 0xB6A7A93E		-- -1230526146
	"UPDATECHARACTER",       -- 0xE4934134		-- -460111564
	"USE",                   -- 0x65736EEA		-- 1702063850

}
