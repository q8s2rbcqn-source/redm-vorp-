local entity_model__to__buoyancy_name = {

	["p_minimine01x"] = {
		"p_minimine01x",
	},
	["s_suppliesraft01x"] = {
		"s_suppliesraft01x",
	},
	["s_warship01x"] = {
		"s_warship01x",
	},
	["s_warship02x"] = {
		"s_warship02x",
	},
	["p_bodypartarmfloat01x"] = {
		"p_bodypartarmfloat01x",
	},
	["p_bodypartarmfloat02x"] = {
		"p_bodypartarmfloat02x",
	},
	["p_bonesskeletonfloat01x"] = {
		"p_bonesskeletonfloat01x",
	},
	["p_carcassverysmallfloat01x"] = {
		"p_carcassverysmallfloat01x",
	},
	["p_planktemp01x"] = {
		"p_planktemp01x",
	},
	["p_barrel02_opencs01x"] = {
		"p_barrel02_opencs01x",
	},
	["s_shipdebris01x_sea"] = {
		"s_shipdebris01x_sea",
	},
	["s_re_toyboat01x"] = {
		"s_re_toyboat01x",
	},
	["s_re_toytorpedo01x"] = {
		"s_re_toytorpedo01x",
	},
	["p_diveflag01x"] = {
		"p_diveflag01x",
	},

}
