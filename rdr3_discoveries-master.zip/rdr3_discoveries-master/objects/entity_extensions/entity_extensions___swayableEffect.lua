local entity_model___to___swayable_effect_name = {

	["p_sca_lemoynebordersign"] = {
		swayable_effect_name = "p_sca_lemoynebordersign",
	},
	["p_sign_church01x"] = {
		swayable_effect_name = "p_sign_church01x",
	},
	["p_sign_open_close01x"] = {
		swayable_effect_name = "p_sign_open_close01x",
	},
	["p_sign_roomsval_a"] = {
		swayable_effect_name = "p_sign_roomsval_a",
	},
	["p_sign_stationrho_a"] = {
		swayable_effect_name = "p_sign_stationrho_a",
	},
	["p_sign_stationrho_b"] = {
		swayable_effect_name = "p_sign_stationrho_b",
	},
	["p_sign_stationrho_c"] = {
		swayable_effect_name = "p_sign_stationrho_c",
	},
	["p_signdoctorrho_a"] = {
		swayable_effect_name = "p_signdoctorrho_a",
	},
	["p_signdoctorrho_b"] = {
		swayable_effect_name = "p_signdoctorrho_b",
	},
	["p_signgunrho_a"] = {
		swayable_effect_name = "p_signgunrho_a",
	},
	["p_signmorgrho_a"] = {
		swayable_effect_name = "p_signmorgrho_a",
	},
	["p_valhotelsign_01x_dmg"] = {
		swayable_effect_name = "p_valhotelsign_01x_dmg",
	},
	["p_valsmithsign01x"] = {
		swayable_effect_name = "p_valsmithsign01x",
	},
	["p_cabinshutterdemoonly01x"] = {
		swayable_effect_name = "p_cabinshutterdemoonly01x",
	},
	["p_charmscreepy01x"] = {
		swayable_effect_name = "p_charmscreepy01x",
	},
	["p_charmscreepy01x_small"] = {
		swayable_effect_name = "p_charmscreepy01x_small",
	},
	["p_spookynative06x_a"] = {
		swayable_effect_name = "p_spookynative06x_a",
	},
	["mp006_s_racexmasflag01x"] = {
		swayable_effect_name = "mp006_s_racexmasflag01x",
	},
	["mp001_s_mp_racecheckflag01x"] = {
		swayable_effect_name = "s_mp_racecheckflag01x",
	},
	["mp001_s_mp_racecheckflag02x"] = {
		swayable_effect_name = "s_mp_racecheckflag02x",
	},
	["mp001_s_mp_racefinishflag01x"] = {
		swayable_effect_name = "s_mp_racefinishflag01x",
	},
	["mp001_s_mpcorona01x"] = {
		swayable_effect_name = "s_mpcorona01x",
	},
	["p_capicola_meat_b"] = {
		swayable_effect_name = "p_capicola_meat_b",
	},
	["p_capicola_meat_b02x"] = {
		swayable_effect_name = "p_capicola_meat_b02x",
	},
	["p_pork_meat_b"] = {
		swayable_effect_name = "p_pork_meat_b",
	},
	["p_lamp03x"] = {
		swayable_effect_name = "p_lamp03x",
	},
	["p_lamp05dx"] = {
		swayable_effect_name = "p_lamp05dx",
	},
	["p_deerguts01x"] = {
		swayable_effect_name = "p_deerguts01x",
	},
	["p_deerhanging01x"] = {
		swayable_effect_name = "p_deerhanging01x",
	},
	["p_deerhanging02x"] = {
		swayable_effect_name = "p_deerhanging02x",
	},
	["p_deerhanging03x"] = {
		swayable_effect_name = "p_deerhanging03x",
	},
	["p_deertuftsfur01x"] = {
		swayable_effect_name = "p_deertuftsfur01x",
	},
	["p_dryingmeat01x"] = {
		swayable_effect_name = "p_dryingmeat01x",
	},
	["p_hanging_badger01x"] = {
		swayable_effect_name = "p_hanging_badger01x",
	},
	["p_hanging_coyote01x"] = {
		swayable_effect_name = "p_hanging_coyote01x",
	},
	["p_hanging_fox01x"] = {
		swayable_effect_name = "p_hanging_fox01x",
	},
	["p_dis_ropebridge"] = {
		swayable_effect_name = "p_dis_ropebridge",
	},
	["p_dis_ropebridge2"] = {
		swayable_effect_name = "p_dis_ropebridge2",
	},
	["p_dis_ropebridge3"] = {
		swayable_effect_name = "p_dis_ropebridge3",
	},
	["p_dis_ropebridge4"] = {
		swayable_effect_name = "p_dis_ropebridge4",
	},
	["p_new_aus_pikebr01"] = {
		swayable_effect_name = "p_new_aus_pikebr01",
	},
	["p_new_aus_pikebr02"] = {
		swayable_effect_name = "p_new_aus_pikebr02",
	},
	["p_new_aus_pikebr03"] = {
		swayable_effect_name = "p_new_aus_pikebr03",
	},
	["p_van_rope_bridge"] = {
		swayable_effect_name = "p_van_rope_bridge",
	},
	["p_disdreamcatcherwind01x"] = {
		swayable_effect_name = "p_disdreamcatcherwind01x",
	},
	["p_disdreamcatcherwind02x"] = {
		swayable_effect_name = "p_disdreamcatcherwind02x",
	},
	["p_disdreamcatcherwind03x"] = {
		swayable_effect_name = "p_disdreamcatcherwind03x",
	},
	["p_disdreamcatcherwind04x"] = {
		swayable_effect_name = "p_disdreamcatcherwind04x",
	},
	["p_disdreamcatcherwind05x"] = {
		swayable_effect_name = "p_disdreamcatcherwind05x",
	},
	["p_diswiskeytreebottlewind01x"] = {
		swayable_effect_name = "p_diswiskeytreebottlewind01x",
	},
	["p_diswiskeytreebottlewind02x"] = {
		swayable_effect_name = "p_diswiskeytreebottlewind02x",
	},
	["p_diswiskeytreebottlewind03x"] = {
		swayable_effect_name = "p_diswiskeytreebottlewind03x",
	},
	["p_panhang"] = {
		swayable_effect_name = "p_panhang",
	},
	["s_shipropes01x"] = {
		swayable_effect_name = "s_shipropes01x",
	},
	["p_ropeswingbroken01x"] = {
		swayable_effect_name = "p_ropeswingbroken01x",
	},
	["p_windmill_top"] = {
		swayable_effect_name = "p_windmill_top",
	},
	["p_targetarchery03x"] = {
		swayable_effect_name = "p_targetarchery03x",
	},
	["p_targetarchery03x_2"] = {
		swayable_effect_name = "p_targetarchery03x_2",
	},
	["p_targetarchery03x_3"] = {
		swayable_effect_name = "p_targetarchery03x_3",
	},
	["p_lantern09xhangwind"] = {
		swayable_effect_name = "p_lantern09xhangwind",
	},
	["p_telescope01x"] = {
		swayable_effect_name = "p_telescope01x",
	},

}
