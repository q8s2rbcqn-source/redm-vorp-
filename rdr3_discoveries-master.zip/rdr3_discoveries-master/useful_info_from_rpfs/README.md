Here i will publish info from rpfs. All this info u can easily find yourself with openIV. But if you are lazy as me and dont want
to surf\search, you can use this folder as reference.