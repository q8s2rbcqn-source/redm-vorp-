Logs            = {}

Logs.WebhookUrl = ""
Logs.color      = 16711680
Logs.logo       = "https://i.imgur.com/4X9Z5bH.png"   -- Replace with your logo URL
Logs.footerlogo = "https://i.imgur.com/4X9Z5bH.png" -- Replace with your footer logo URL	
Logs.avatar     = "https://i.imgur.com/4X9Z5bH.png" -- Replace with your avatar URL




Logs.DeleteCharacterWebhhok = {
    NotFound    = "Character not found",
    Title       = "Delete Character",
    WebhookName = "Character Deletion",
}
