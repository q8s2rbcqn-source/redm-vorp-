***
# vorp character Lua 
***
Lua version of Vorp character <br>
Character creation for RedM 


## Requirments

* VORP CORE lua
* VORP INPUTS lua

## Instalation
* Simply drag and drop to the folder called `resources/vorp_official_plugins/vorp_essential`
* ensure vorp_charater in the `resources.cfg`
* restart server

## Notes

*  update `vorp_clothingstores-lua`
*  update `vorp_barbershop-lua`


# License

#### vorp frame work
***
Copyright (C) 2022 outsider

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

`You are not authorized to modify any offical plug-ins for comercial use, if you do you must publish the code for the public. read the terms and conditions of the license provided`

***

# Credits

* C# original script 
* grumpypoo  `initial conversion`
* black pegasus `initial conversion`
* outsider  `refactor`








