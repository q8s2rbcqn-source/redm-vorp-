# vorp menu 

RedM menu API

# insatallation

- `ensure vorp_menu` in the top of your resources/server.cfg 

# Documentation

[vorp_menu](https://docs.vorp-core.com/api-reference/menu)


## Images

![image](https://github.com/user-attachments/assets/70c83c6d-69b3-4c1c-ad3f-4d325b30db34)
![image](https://github.com/user-attachments/assets/4aa44c68-b1d5-4b6c-aa0a-44bcf0f3d50c)


## video
https://github.com/user-attachments/assets/01808aae-41e9-42ab-87f6-a003a5bfe921



# Credits
* @SLIZZARN
