function CheckMode(mode) 
    return  mode == 'table' or mode == 'json' or mode == 'array'
end